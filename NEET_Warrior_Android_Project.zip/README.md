# NEET Warrior Android project

This is an Android WebView wrapper around the NEET Warrior study app. It enables JavaScript and DOM storage so chapter progress and settings can be stored locally in the app's WebView storage.

## Build APK automatically (no Android Studio required, but a GitHub account is needed)
1. Create a new GitHub repository.
2. Upload all files and folders from this project ZIP to the repository's `main` branch.
3. Open the repository's **Actions** tab and select **Build NEET Warrior APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When the run finishes, open it and download the `NEET-Warrior-debug-APK` artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Open it on Android and allow installation from that source if Android asks.

## Build locally
Open this folder in Android Studio with Android SDK Platform 35 installed, then run the `assembleDebug` Gradle task. The output is `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The included APK is configured as a debug build and is suitable for personal testing, not Play Store publication.
- The app's web assets are stored locally inside the APK; it does not require web hosting.
- App progress is stored in the app's WebView local storage. Android app data clearing/uninstalling may erase it; use the in-app JSON backup feature.
- Starter chapters are examples, not a complete official NEET syllabus.
